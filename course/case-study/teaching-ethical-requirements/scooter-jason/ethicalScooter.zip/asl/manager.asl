/* Plans for making a scooter reservation. */
/* It makes a reservation. */
+!reservation(Id, Client):
    scooter(Id, free, _) <-
	-scooter(Id, _, _);
	+scooter(Id, reserved, Client);
	.print("Reservation made for scooter ", Id, " and user ", Client, ".");
	!reportStatus.

/* It is not possible to book if the scooter is busy. */
+!reservation(Id, Client):
    scooter(Id, busy, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to make a reservation is busy.").

/* It is not possible to book if the scooter is already reserved. */
+!reservation(Id, Client):
    scooter(Id, reserved, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to make a reservation is already reserved.").

/* It is not possible to book if the scooter is inactive. */
+!reservation(Id, Client):
    scooter(Id, inactive, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to make a reservation is out of service and waiting for maintenance.").

/* It is not possible to book if the scooter is not in this zone. */
+!reservation(Id, Client):
    not scooter(Id, _, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to make a reservation is not at Campus Valla anymore.").	

/* Plans for starting the use of a scooter. */
/* It starts the use of a scooter. */
+!start(Id, Client):
    (scooter(Id, reserved, Client) |
    scooter(Id, free, _)) &
    not scooter(_, busy, Client) <-
	-scooter(Id, _, _);
	+scooter(Id, busy, Client);
	.print("User ", Client, " started using scooter ", Id, ".");
	!!reportStatus;
	!incrementDemand;
	!sumAllocations(Total);
	.send(distribution, tell, newAccumulatedAllocations(Total)).

/* It is not possible to use a new scooter while you are using another. */
+!start(Id, Client):
    scooter(_, busy, Client) <-
	!auditAndReply(Id, Client, "You already have a scooter in use.").

/* It is not possible to use a scooter if it is busy. */
+!start(Id, Client):
    scooter(Id, busy, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to use is busy.").

/* It is not possible to use a scooter if it is reserved to other user. */
+!start(Id, Client):
    scooter(Id, reserved, Holder) &
    Client \== Holder <-
	!auditAndReply(Id, Client, "The scooter you've tried to use is reserved for another user.").

/* It is not possible to use an inactive scooter. */
+!start(Id, Client):
    scooter(Id, inactive, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to use is out of service and waiting for maintenance.").

/* It is not possible to use a scooter if it is not in this zone. */
+!start(Id, Client):
    not scooter(Id, _, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to use is not at this zone anymore.").	

/* Plans for returning a scooter. */		
/* It returns a scooter. */
+!return(Id, Client):
    scooter(Id, busy, Client) <-
	-scooter(Id, _, _);
	+scooter(Id, free, none);
	.print("Scooter ", Id, " returned by ", Client, ".");
	!reportStatus.

/* It is not possible to return a scooter if it is in use by another user. */
+!return(Id, Client):
    scooter(Id, busy, Holder) &
    Client \== Holder <-
	!auditAndReply(Id, Client, "The scooter you've tried to return is in use by another user.").

/* It is not possible to return a scooter if it is free. */
+!return(Id, Client):
    scooter(Id, free, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to return is not in use.").

/* It is not possible to return a scooter if it is reserved to someone. */
+!return(Id, Client):
    scooter(Id, reserved, Holder) &
    Client \== Holder <-
	!auditAndReply(Id, Client, "The scooter you've tried to return is not in use and reserved to another user.").

/* It is not possible to return a scooter if it is not in use even if reserved by the same user. */
+!return(Id, Client):
    scooter(Id, reserved, Client) <-
	!auditAndReply(Id, Client, "The scooter you've tried to return is not in use although reserved by you."). 

/* It is not possible to retunr a scooter if it is inactive. */
+!return(Id, Client):
    scooter(Id, inactive, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to return is out of service and waiting for maintenance.").

/* It is not possible to return a scooter that is not in this zone. */
+!return(Id, Client):
    not scooter(Id, _, _) <-
	!auditAndReply(Id, Client, "The scooter you've tried to return is not in this zone anymore.").