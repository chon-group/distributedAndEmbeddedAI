{include("printer.asl")}
{include("calculator.asl")}
{include("batching.asl")}
{include("loader.asl")}

agents::maintenance_agent(maintenance).
agents::zone_agent(zoneLambohov).
agents::zone_agent(zoneCampusValla).
agents::zone_agent(zoneInnerstaden).

config::config_low_stock(5).
config::allocationRate(20).
config::zoneTransferRate(15).
config::maintenanceThreshold(2).

!initialAllocation.

/* It receives a zone belief from a zone and translates it to a zone_status belief removing the previous one. */
+zone(zone(Area),
      type(Type),
      demand(Demand),
      available(A),
      inactive(U),
      event(Event))[source(Client)] <-
	.abolish(zone_status(zone(_),
                 type(_),
                 demand(_),
                 available(_),
                 inactive(_),
                 event(_))[source(Client)]);	
	.abolish(zone( _, _, _, _, _, _)[source(Client)]);
		+zone_status(zone(Area),
	     	     type(Type),
	     	     demand(Demand),
	     	     available(A),
	     	     inactive(U),
	     	     event(Event))[source(Client)].

+zone_status(
    zone(Z),
    type(T),
    demand(D),
    available(A),
    inactive(I),
    event(E))[source(Sender)] <-
	!printZoneStatus(Sender, Z, T, D, A, I, E);
	-last_available(Z, _);
    	+last_available(Z, A);
	-zone_status(
        	zone(Z),
        	zone_name(X),
        	type(T),
        	demand(D),
        	available(A),
        	inactive(I),
        	event(E)[source(Sender)]);
	!decideDistribution(Z, T, D, A, I, E).

+scooter(Id, X, Y) <-
	.print("I received the scooter ", Id, " refurbished.").
	
+!decideDistribution(Zone, _, _, _, _, Event) :
    config::allocationRate(Rate) & 
    Event \== none <-
    	!calculateTransferQuantity(Zone, Qty);
	.print("[PEAK EVENT] Prioritize redistribution of ", Qty ," scooter(s) to zone ", Zone, " to meet event ", Event, ".");
	!allocateScooters(Zone, Qty, event).

+!decideDistribution(Zone, _, _, _, Inactives, _):
    config::maintenanceThreshold(Limit) &
    Inactives >= Limit &
    not movingInProgress(Zone) <-
    	.print("Asking ", Inactives, " inactive scooters to move from ", Zone, " to maintenance.");
    	!askToMove(Zone).

+!decideDistribution(Zone, _, high, Available, _, _):
    config::config_low_stock(Stock) & 
    Available < Stock <-
	!calculateTransferQuantity(Zone, Qty);
	.print("[HIGH DEMAND]: Attending high demand and low availability in ", Zone, ". Trying to send ", Qty, " scooters.");
 	!allocateScooters(Zone, Qty, demand).

// PERCEBA QUE AQUI ELE ALOCA INDEPENDENTE DA QUANTIDADE E DA COMO ATENDIDO. SE HOUVER 1, ALOCA.
@tiodu[atomic]
+!allocateScooters(Zone, Qty, _): 	
    .findall(scooter(Id, free, none), scooter(Id, free, none), FreeScooters) &
    FreeScooters \== [] <-
	!select(Qty, FreeScooters, SelectedScooters);
	!removeScooters(SelectedScooters);
	.send(Zone, tell, SelectedScooters);
	!increaseAvailability(Zone, Qty);
	.print("Sending ", Qty, " scooters (", SelectedScooters, ") to ", Zone, ".").

/* There is no free scooters in distribution at this time. */
+!allocateScooters(Zone, Qty, Type):
    .findall(scooter(Id, free, none), scooter(Id, free, none), FreeScooters) &
    FreeScooters == [] <-
	.print("There is no available scooters in distribution right now. Let's search in another Zone.");
	!!transferFromAnotherZone(Zone, Type);
	.fail.

+!removeScooters([scooter(Id, _, _)|Rest]) <-
	-scooter(Id, _, _)[source(_)];
	!removeScooters(Rest).

+!removeScooters([]). 	

-!decideDistribution(Zone, _, _, _, _, Event).

+!askToMove(Zone) <-
    	.send(Zone, achieve, removeInactives);
	+movingInProgress(Zone)[source(Zone)].

// ==============================
// ZONE TRANSFER
// ==============================

+!transferFromAnotherZone(TargetZone, Type):
    agents::zone_agent(SourceZone) &
    SourceZone \== TargetZone &
    last_available(SourceZone, Available) &
    Available > 0 &
    config::zoneTransferRate(Rate) &
    not transferInProgress(SourceZone, TargetZone)[source(SourceZone)] <-
	+transferInProgress(SourceZone, TargetZone)[source(SourceZone)];
    	!calculatePercentage(Available, Rate, BaseQty);
    	Qty = math.max(1, BaseQty);
	.print("[ZONE TRANSFER] Asking for ", SourceZone, " for transferring ", Qty, " scooter(s) to ", TargetZone, ".");
	.send(SourceZone, achieve, transferScooters(TargetZone, Qty));
	!inform(TargetZone, Type).
	
+!transferFromAnotherZone(TargetZone, _):
    transferInProgress(SourceZone, TargetZone)[source(SourceZone)] <-
	.print("[ZONE TRANSFER] There is an active transferring occurring for ", TargetZone, ".").

+!inform(Zone, event) <-
	.send(Zone, tell, setEvent(event(none))).

+!inform(Zone, demand).

+transferred_scooters(TargetZone, Scooters)[source(SourceZone)] <-
	.print("Received scooters from ", SourceZone, " to forward to ", TargetZone, ": ", Scooters, ".");
	.send(TargetZone, tell, Scooters);
	-transferred_scooters(TargetZone, Scooters)[source(SourceZone)].