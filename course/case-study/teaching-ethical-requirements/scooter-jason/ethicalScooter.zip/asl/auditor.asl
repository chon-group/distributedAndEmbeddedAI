/* It receives a requisition for explaining a ticket. It answers with the reason and the responsible for the decision. */
+!requisition(Id)[source(Client)]:
	operation(Id, Client, Responsible, Message, Type) <-
		.print(
    			"[", Id, "]: Requisition number ", Id, " received.",
    			"\n[", Id, "]: ", Message,
    			"\n[", Id, "][Responsible]: ", Responsible,
        		"\n"
		);
		.send(Client, tell, request(Id, Responsible, Message, Type)).

/* It receives a requisition for explaining a ticket. */
+!explainability(Id)[source(Client)]:
	operation(Id, Client, Responsible, Message, explainability) <-
		.print(
    			"[", Id, "]: Requisition number ", Id, " received.",
    			"\n[", Id, "]: ", Message,
        		"\n"
		);
		.send(Client, tell, request(Id, Responsible, Message, Type)).

/* It receives a requisition for accounting a ticket. */
+!accountability(Id)[source(Client)]:
	operation(Id, Client, Responsible, Message, accountability) <-
		.print(
    			"[", Id, "]: Requisition number ", Id, " received.",
    			"\n[", Id, "]: ", Message,
        		"\n"
		);
		.send(Client, tell, request(Id, Responsible, Message, Type)).

/* It receives a requisition for finding the responsible for the decision of a ticket. */
+!responsibility(Id)[source(Client)]:
	operation(Id, Client, Responsible, Message, _) <-
		.print(
    			"[", Id, "]: Requisition number ", Id, " received.",
    			"\n[", Id, "][Responsible]: ", Responsible,
        		"\n"
		);
		.send(Client, tell, request(Id, Responsible, Message, Type)).

/* The client does not have access to the ticket. */
-!requisition(Id)[source(Client)] <- 
		.print("The client ", Client, " does not have access to id ", Id ,".").

/* The ticket does not exist for this motive. */
-!explainability(Id)[source(Client)] <-
		.print("There is no explainability related to id ", Id ,".").

/* The ticket does not exist for this motive. */
-!accountability(Id)[source(Client)] <-
		.print("There is no accountability related to id ", Id ,".").

/* The client does not have access to the ticket. */
-!responsibility(Id)[source(Client)] <-
		.print("The client ", Client, " does not have access to id ", Id ,".").