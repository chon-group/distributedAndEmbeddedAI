//!start.

+!start <-
	.send(booking, achieve, reservation(6));
	.wait(3000);
	.send(booking, achieve, start(1));
	.wait(3000);
	.send(booking, achieve, return(8));
	.wait(3000);
	.send(booking, achieve, return(9));
	.wait(3000);
	.send(booking, achieve, start(10)).

+!explainToMe <-
	.send(auditor, achieve, requisition(1));
	.send(auditor, achieve, responsibility(3)).

+ticket(Id) <-
	.print("I received the ticket ", Id, ".");
	.send(auditor, achieve, accountability(Id));
	.send(auditor, achieve, responsibility(Id)).
