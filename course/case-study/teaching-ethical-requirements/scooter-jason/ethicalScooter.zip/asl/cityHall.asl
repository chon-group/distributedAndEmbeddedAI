/* It considers an Id, the zone agent, and the event using a Term.*/
event(1, zoneCampusValla, campus_party).
event(2, zoneLambohov, evening_show).
event(3, zoneLambohov, evening_show).

eventInterval(10000).
currentEvent(1).

!start.

+!start <-
    	.print("Starting communicating events to the zones.");
    	.wait(10000);
	.send(zoneLambohov, tell, setDemand(high));
    	.wait(5000);
	!nextEvent.

/* It starts by getting the first event and informing the respective zone. */
+!nextEvent:
    currentEvent(Index) &
    event(Index, Zone, Event) <-
    	!informEvent(Index, Zone, Event);
    	?eventInterval(Time);
    	.wait(Time);
    	!nextEvent.

/* If there is no next event, the agent stops. */
+!nextEvent:
    currentEvent(Index) &
    not event(Index, _, _) <-
    	.print("All programmed events were communicated to their respective zones.").

+!informEvent(Index, Zone, Event) <-
	.print("Sending event ", Event, " to ", Zone, ".");
    	.send(Zone, tell, setEvent(Event));
    	-currentEvent(Index);
    	NextIndex = Index + 1;
    	+currentEvent(NextIndex).