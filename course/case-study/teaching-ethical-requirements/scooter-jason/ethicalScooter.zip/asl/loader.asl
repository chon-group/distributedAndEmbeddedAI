/* It will distribute the scooters to their respective zones. */
/* Scooter has Id, Status (free, reserved, busy, maintenance, or inactive), and client. */
+!initialAllocation <-
	!caseTest1.

/* CASE TEST 1: for inactives, events and high demand. */
+!caseTest1 <- 
	.send(zoneCampusValla, 
	      tell,
	      [
		scooter(1, free, none),
		scooter(2, reserved, bob),
		scooter(3, inactive, none),
		scooter(4, inactive, none),
		scooter(5, inactive, none),
		scooter(6, inactive, none),
		scooter(7, inactive, none),
		scooter(8, inactive, none),
		scooter(9, inactive, none),
		scooter(10, inactive, none)
	      ]
	);
	.send(zoneLambohov, 
	      tell,
	      [
		scooter(11, free, none),
		scooter(12, reserved, bob),
		scooter(13, inactive, none),
		scooter(14, inactive, none),
		scooter(15, inactive, none),
		scooter(16, inactive, none),
		scooter(17, inactive, none),
		scooter(18, inactive, none),
		scooter(19, inactive, none),
		scooter(20, inactive, none)
	      ]
	).

/* CASE TEST 2: for low stock of scooters in distribution. */
+!caseTest2 <- 
	.send(zoneCampusValla, 
	      tell,
	      [
		scooter(1, free, none),
		scooter(2, reserved, teddy),
		scooter(3, free, none),
		scooter(4, free, none),
		scooter(5, free, none),
		scooter(6, free, none),
		scooter(7, free, none),
		scooter(8, free, none),
		scooter(9, free, none),
		scooter(10, free, none)
	      ]
	);
	.send(zoneLambohov, 
	      tell,
	      [
		scooter(11, free, none),
		scooter(12, reserved, carmen),
		scooter(13, free, none),
		scooter(14, free, none),
		scooter(15, free, none),
		scooter(16, free, none),
		scooter(17, free, none),
		scooter(18, free, none),
		scooter(19, free, none),
		scooter(20, free, none)
	      ]
	);
	.send(zoneInnerstaden, 
	      tell,
	      [
		scooter(21, free, none),
		scooter(22, reserved, kate),
		scooter(23, free, none),
		scooter(24, free, none),
		scooter(25, free, none),
		scooter(26, free, none),
		scooter(27, free, none),
		scooter(28, free, none),
		scooter(29, free, none),
		scooter(30, free, none)
	      ]
	).