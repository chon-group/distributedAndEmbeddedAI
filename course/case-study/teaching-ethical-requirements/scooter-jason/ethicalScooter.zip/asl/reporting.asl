/* It counts all free scooters from a zone. */
+!countAvailableScooters(Qtt) <-
	.findall(Id, scooter(Id, free, _), FreeScootersList);
    	.length(FreeScootersList, Qtt).

/* It counts all busy scooters from a zone. */
+!countUnavailableScooters(Qtt) <-
    	.findall(Id, scooter(Id, busy, _), BusyScootersList);
    	.length(BusyScootersList, Qtt).

/* It counts all reserved scooters from a zone. */
+!countReservedScooters(Qtt) <-
    	.findall(Id, scooter(Id, reserved, _), ReservedScootersList);
    	.length(ReservedScootersList, Qtt).

/* It counts all inactive scooters from a zone. */
+!countInactiveScooters(Qtt) <-
    	.findall(Id, scooter(Id, inactive, _), InactiveScootersList);
    	.length(InactiveScootersList, Qtt).

/* It sums the total of allocations of all time. In this version, there is only 2026 allocations. */
+!sumAllocations(Total) <-
	.findall(Value, allocations::totalAllocations(Value, _, _), List);
	Total = math.sum(List).

/* It sums the total of restrictions of all time. In this version, there is only 2026 restrictions. */
+!sumRestrictions(Total) <-
	.findall(Value, restrictions::totalRestrictions(Value, _, _), List);
	Total = math.sum(List).

/* It increments the allocation demand for the current month. */
+!incrementDemand: 
    .date(Year, Month, _) &
    allocations::totalAllocations(Qtt, Month, Year) <-
	-allocations::totalAllocations(Qtt, Month, Year);
	+allocations::totalAllocations(Qtt + 1, Month, Year);
	.print("Updating the monthly demand.").

/* It creates the first allocation for the current month. */    
+!incrementDemand: 
    .date(Year, Month, _) <-
	+allocations::totalAllocations(1, Month, Year);
	.print("Creating the first demand this month.").

/* It increments the restrictions for the current month. */
+!incrementRestriction: 
    .date(Year, Month, _) &
    restrictions::totalRestrictions(Qtt, Month, Year) <-
	-restrictions::totalRestrictions(Qtt, Month, Year);
	+restrictions::totalRestrictions(Qtt + 1, Month, Year);
	.print("Updating the monthly restrictions.").

/* It creates the first restriction for the current month. */     
+!incrementRestriction: 
    .date(Year, Month, _) <-
	+restrictions::totalRestrictions(1, Month, Year);
	.print("Creating the first restriction this month.").

/* It reports to the distribution some information. */ 
+!reportStatus:
    type(T) &
    event(E) &
    demand(D) <-
    	.my_name(Me);	
	!countAvailableScooters(A);
	!countInactiveScooters(I);
	.print("Reporting! Available: ", A, " - Inactives: ", I, ".");
	.send(distribution, tell, zone(zone(Me),
            			       type(T),
            			       demand(D),
            			       available(A),
            			       inactive(I),
            			       event(E))			       			
	);
	!sumAllocations(Allocations);
	.send(distribution, tell, newAccumulatedAllocations(Allocations));
	!sumRestrictions(Repressed);
	.send(distribution, tell, newAccumulatedRepressed(Repressed)).

/* It receives from booking and increment restrictions. */
+restrained <-
	.abolish(restrained);
 	!incrementRestriction;
	!sumRestrictions(Total);
	.send(distribution, tell, newAccumulatedRepressed(Total)).	