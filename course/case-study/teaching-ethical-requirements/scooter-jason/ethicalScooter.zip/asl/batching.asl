/* It recursively selects the first Qtt items from a list and returns the selected items in the Selecteds list. */ 
+!select(Qtt, [Next|Rest], [Next|Selecteds]):
    Qtt > 0 <-
    	NewQtt = Qtt - 1;
    	!select(NewQtt, Rest, Selecteds).

+!select(0, _, []).

+!select(_, [], []).
