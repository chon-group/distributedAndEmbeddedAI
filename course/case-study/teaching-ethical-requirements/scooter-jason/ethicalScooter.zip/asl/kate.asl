//!start.

+!start <-
	.send(booking, achieve, reservation(2));
	.wait(2000);
	.send(booking, achieve, return(8));
	.wait(2000);	
	.send(booking, achieve, start(9));
	.wait(2000);
	.send(booking, achieve, informUnavailability(zoneLambohov)).


+ticket(Id) <-
	.print("I received the ticket ", Id, ".");
	.send(auditor, achieve, accountability(Id));
	.send(auditor, achieve, responsibility(Id)).