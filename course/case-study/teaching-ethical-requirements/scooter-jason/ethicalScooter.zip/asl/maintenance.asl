maintenance_capacity(2).
ready_transfer_threshold(4).

+scooter(Id, _, _) <- 
	!processRepair.

+!processRepair: 
    not repairing <-
	+repairing;
	!checkRepairs.

+!processRepair: 
    repairing <- 
	.print("Our Staff is totally busy right now!").

+!checkRepairs: 	
    .findall(scooter(Id, inactive, none), scooter(Id, inactive, none), InactiveScooters) &
    .length(InactiveScooters, Qty) <-
	!selectScooters(InactiveScooters, Qty).

+!checkRepairs <-
    	.print("There is scooters to repair.").

+!selectScooters(InactiveScooters, Qty): 
    Qty >= 2 <-	
	+repairing;
	.print("I've got 2 or more to fix: ", InactiveScooters);
	!selectScootersToRepair(InactiveScooters, []).

+!selectScooters(InactiveScooters, Qty): 
    Qty == 1 <-	
	.print("I've got 1 to fix: ", InactiveScooters);
	!repairScooters(InactiveScooters).

+!selectScooters(InactiveScooters, Qty): 
    Qty == 0 <-	
	-repairing;
	.print("I don't have scooters to fix.").
	
+!selectScootersToRepair([], List) <-
    	.print("Selected scooters: ", List);
	!repairScooters(List).

+!selectScootersToRepair([scooter(Id, Status, Ref)|Rest], List):
    .length(List, Qtt) &
    Qtt < 2 <-
    	.print("Selecting scooter ", Id, " to repair.");
    	NewList = [scooter(Id, Status, Ref)|List];
    	!selectScootersToRepair(Rest, NewList).

+!selectScootersToRepair(_, List):
    .length(List, Qtt) &
    Qtt >= 2 <-
    	.print("Repair limit reached: ", List);
	!repairScooters(List).

+!repairScooters([scooter(Id, Status, Ref)|Rest]) <-		 
	.wait(1000);
	.print("Repairing ", scooter(Id, Status, Ref));
	-scooter(Id, _, _)[source(Zone)];
	+scooter(Id, free, none)[source(Zone)];
	!repairScooters(Rest).

+!repairScooters([]) <- 
    	-repairing;
    	.print("Repair process finished.");
    	!sendScootersToDistribution;
	!processRepair.
	
+!repairScooters([scooter(Id, Status, Ref)]) <- 
    	-repairing;
    	.print("Repair process finished.");
    	!sendScootersToDistribution;
	!processRepair.

+!sendScootersToDistribution: 
    .findall(scooter(Id, free, none), scooter(Id, free, none), ReadyScooters) &
    .length(ReadyScooters, Qtt) &
    ready_transfer_threshold(Threshold) &
    Qtt >= Threshold <- 
	.print("Sending the following scooters to the Distribution: ", ReadyScooters);
	.send(distribution, tell, ReadyScooters);
	!removeSentScooters(ReadyScooters).

+!sendScootersToDistribution <-
	.print("Waiting for more ready scooters until reach the minimun threshold.").

+!removeSentScooters([scooter(Id, _, _)|Rest]) <-
	-scooter(Id, _, _)[source(_)];
	!removeSentScooters(Rest).

+!removeSentScooters([]).