{include("manager.asl")}
{include("reporting.asl")}
{include("tracer.asl")}
{include("fleet.asl")}
{include("marketing.asl")}

/* Demand and Satisfaction could be low, medium, or high. 
 * Satisfaction could also be evaluation.
 * Hard-coded beliefs. */
type("Neighborhood").
demand(low).
event(none).

/* Historical allocations. */
allocations::totalAllocations(15, 1, 2026).
allocations::totalAllocations(10, 2, 2026).
allocations::totalAllocations(18, 3, 2026).
allocations::totalAllocations(22, 4, 2026).

/* Historical restrictions. */
restrictions::totalRestrictions(11, 1, 2026).
restrictions::totalRestrictions(10, 2, 2026).
restrictions::totalRestrictions(12, 3, 2026).
restrictions::totalRestrictions(14, 4, 2026).

!reportStatus.

+ticket(Id) <-
	.print("I received the ticket ", Id, ".");
	.send(auditor, achieve, accountability(Id));
	.send(auditor, achieve, responsibility(Id)).