/* It starts the process of removing inactives scooters to maintenance. */ 
+!removeInactives <-
    .findall(Id, scooter(Id, inactive, _), InactiveScooters);
    .print("Inactive scooters found: ", InactiveScooters);
    !moveInactives(InactiveScooters).

/* It iterates the inactive list to move scooter by scooter to maintenance. */
+!moveInactives([Id|Rest]) <-
    !moveToMaintenance(Id);
    !moveInactives(Rest).

/* The inactive list has reached to its end. */
+!moveInactives([]) <-
	.my_name(Me);
	.send(distribution, untell, movingInProgress(Me)).

/* It moves a scooter to maintenance. */
+!moveToMaintenance(Id):
    scooter(Id, _, _) <-
	-scooter(Id, _, _)[source(_)];
	.send(maintenance, tell, scooter(Id, inactive, none));
	.print("Sent scooter ", Id, " to maintenance agent.");
	.send(booking, tell, fromMaintenance(Id)).

/* If the scooter is not in this zone, it informs the auditor. */
+!moveToMaintenance(Id):
    not scooter(Id, _, _) <-
	.my_name(Client);
	!auditAndReply(Id, Client, "The scooter you've tried to move is not at this zone anymore.").		

/* It starts the process to transfers scooters to another zone. The distribution agent activates this plan by sending an achieve message. */
+!transferScooters(TargetZone, Qty)[source(distribution)] <-
    	.findall(scooter(Id, free, none),
                 scooter(Id, free, none),
                 FreeScooters);
    	.length(FreeScooters, Available);
	!checkAvailability(TargetZone, Qty, Available, FreeScooters);
	.my_name(Me);
	.send(distribution, untell, transferInProgress(Me, TargetZone)).

+!checkAvailability(TargetZone, Qty, Available, FreeScooters):
    Available >= Qty <-
	!selectScooters(Qty, FreeScooters, SelectedScooters);
	!removeScooters(SelectedScooters);
	.send(distribution, tell, transferred_scooters(TargetZone, SelectedScooters));
	.send(booking, tell, fromZone(TargetZone, SelectedScooters)).

+!checkAvailability(TargetZone, Qty, Available, FreeScooters):
    Available < Qty <-
	.print("There isn't enough scooters to transfer.").

/* It selects scooters recursively. */ 
+!selectScooters(Qty, [Scooter|Rest], [Scooter|Selected]) :
     Qty > 0 <-
    	NewQty = Qty - 1;
    	!selectScooters(NewQty, Rest, Selected).

/* The base case when the quatity selected hits zero. */
+!selectScooters(0, _, []).

/* Removes the scooters from this zone. */
+!removeScooters([scooter(Id, _, _)[source(_)]|Rest]) <-
	-scooter(Id, _, _)[source(_)];
    	!removeScooters(Rest).

/* All selected scooters have been transferred. */
+!removeScooters([]) <-
    	.print("All selected scooters have been transferred.").

+scooter(Id, free, none)[source(distribution)] <-
	.my_name(Me);
	.print("I received the scooter ", Id, " from distribution.");
	.send(booking, tell, fromZone(scooter(Id, Me))).