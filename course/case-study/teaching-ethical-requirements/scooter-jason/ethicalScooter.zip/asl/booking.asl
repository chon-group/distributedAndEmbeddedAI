{include("tracer.asl")}

/* All scooters from campusValla zone. */
scooter(1, zoneCampusValla)[source(zoneCampusValla)].
scooter(2, zoneCampusValla)[source(zoneCampusValla)].
scooter(3, zoneCampusValla)[source(zoneCampusValla)].
scooter(4, zoneCampusValla)[source(zoneCampusValla)].
scooter(5, zoneCampusValla)[source(zoneCampusValla)].
scooter(6, zoneCampusValla)[source(zoneCampusValla)].
scooter(7, zoneCampusValla)[source(zoneCampusValla)].
scooter(8, zoneCampusValla)[source(zoneCampusValla)].
scooter(9, zoneCampusValla)[source(zoneCampusValla)].
scooter(10, zoneCampusValla)[source(zoneCampusValla)].

/* All scooters from lambohov zone. */
scooter(11, zoneLambohov)[source(zoneLambohov)].
scooter(12, zoneLambohov)[source(zoneLambohov)].
scooter(13, zoneLambohov)[source(zoneLambohov)].
scooter(14, zoneLambohov)[source(zoneLambohov)].
scooter(15, zoneLambohov)[source(zoneLambohov)].
scooter(16, zoneLambohov)[source(zoneLambohov)].
scooter(17, zoneLambohov)[source(zoneLambohov)].
scooter(18, zoneLambohov)[source(zoneLambohov)].
scooter(19, zoneLambohov)[source(zoneLambohov)].
scooter(20, zoneLambohov)[source(zoneLambohov)].

/* All scooters from Innerstaden zone. */
scooter(21, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(22, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(23, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(24, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(25, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(26, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(27, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(28, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(29, zoneInnerstaden)[source(zoneInnerstaden)].
scooter(30, zoneInnerstaden)[source(zoneInnerstaden)].

/* It receives a start request from an user and redirects it to a specific Zone. */
+!start(Id)[source(Client)]:
    scooter(Id, Zone) &
    Zone \== maintenance <-
		.send(Zone, achieve, start(Id, Client)).	

/* It is not possible to start a scooter if it is maintenance. */
+!start(Id)[source(Client)]:
    scooter(Id, Zone) &
    Zone == maintenance <-
	!auditAndReply(Id, Client, "The scooter you've tried to use is under maintenance.").


/* It receives a return request from an user and redirects it to a specific Zone. */
+!return(Id)[source(Client)]:
	scooter(Id, Zone) &
	Zone \== maintenance <-
		.send(Zone, achieve, return(Id, Client)).

/* It is not possible to return a scooter if it is maintenance. */
+!return(Id)[source(Client)]:
    scooter(Id, Zone) &
    Zone == maintenance <-
	!auditAndReply(Id, Client, "The scooter you've tried to return is under maintenance.").

/* It receives a book request from an user and redirects it to a specific Zone. */
+!reservation(Id)[source(Client)]:
	scooter(Id, Zone) &
	Zone \== maintenance <-
		.send(Zone, achieve, reservation(Id, Client)).		

/* It receives a unavailability from a user and redirects it to a specific Zone. */
+!informUnavailability(Zone) <-
	.send(Zone, tell, restrained).

/* It receives a belief from a zone specifying that a scooter is under maintenance. */
+fromMaintenance(Id) <-
	.abolish(fromMaintenance(Id));
	-scooter(Id, _)[source(_)];	
	+scooter(Id, maintenance)[source(maintenance)].

+fromZone(scooter(Id, Client)) <-
	.abolish(fromZone(_));
	-scooter(Id, _)[source(_)];
	+scooter(Id, Client)[source(Client)].

+fromZone(Client, [scooter(Id, _, _)|Rest]) <-
	.abolish(fromZone(Client,_));
	+fromZone(scooter(Id, Client));
	+fromZone(Client, Rest).

+fromZone(Client, []) <-
	.abolish(fromZone(Client,[])).