/* It sets a new event informed by the City Hall for this zone. */ 
+setEvent(NewEvent)[source(cityHall)]:
    event(CurrentEvent) <-
	.abolish(setEvent(NewEvent));
	-event(CurrentEvent);
    	+event(NewEvent);
	.print("New event ", NewEvent, " detected. Changing from ", CurrentEvent, " to ", NewEvent, ".");
	!reportStatus.

/* It sets an event as attended by the Distribution by inserting none in the Belief. */ 
+setEvent(event(NewEvent))[source(distribution)]:
    event(CurrentEvent) <-
	.abolish(setEvent(event(NewEvent)));
	-event(CurrentEvent);
    	+event(NewEvent);
	.print("The event ", CurrentEvent, " was attended by the Distribution.").

+setDemand(NewDemand) <-
	.abolish(setDemand(NewDemand));
	-demand(_);
	+demand(NewDemand);
	!reportStatus.