/* It receives the accumulated allocations from a zone and translates it to a accumulatedAllocations belief removing the previous one. */
+newAccumulatedAllocations(Value)[source(Zone)] <-
	.abolish(newAccumulatedAllocations(_)[source(Zone)]);	 	
    	-indicators::accumulatedAllocations(Zone,_)[source(Zone)];
	+indicators::accumulatedAllocations(Zone, Value)[source(Zone)].

/* It receives the accumulated repressed demand from a zone and translates it to a repressedAllocations belief removing the previous one. */
+newAccumulatedRepressed(Value)[source(Zone)] <-
	.abolish(newAccumulatedRepressed(_)[source(Zone)]);	 	
    	-indicators::accumulatedRepressed(Zone,_)[source(Zone)];
	+indicators::accumulatedRepressed(Zone, Value)[source(Zone)].

/* It calculates the scooters to be transferred based on the average allocations. */
+!calculateTransferQuantity(Zone, Qtt):
    indicators::accumulatedAllocations(Zone, Allocations) &
    config::allocationRate(Rate) <-
	.date(_, Month, _);
    	Average = Allocations / Month;
    	!calculatePercentage(Average, Rate, Qtt).

/* If there is no historical allocations in this zone, it defines 1 scooter to be tranferred. */ 
+!calculateTransferQuantity(Zone, Qtt):
    not indicators::accumulatedAllocations(Zone,_) <-
    	Qtt = 1.

+!calculatePercentage(Value, Rate, Result) <-
    	Result = math.ceil((Value * Rate) / 100).

+!increaseAvailability(Zone, Qty):
    last_available(Zone, Available) <-
    	-last_available(Zone, Available);
    	NewAvailable = Available + Qty;
    	+last_available(Zone, NewAvailable).

+!increaseAvailability(Zone, Qty):
    not last_available(Zone, _) <-
    	+last_available(Zone, Qty).

+!decreaseAvailability(Zone, Qty):
    last_available(Zone, Available) <-
    	-last_available(Zone, Available);
    	NewAvailable = Available - Qty;
    	+last_available(Zone, NewAvailable).

+!decreaseAvailability(Zone, Qty):
    not last_available(Zone, _) <-
    	.print("Não há registro local de disponibilidade para ", Z).
