{include("manager.asl")}
{include("reporting.asl")}
{include("tracer.asl")}
{include("fleet.asl")}
{include("marketing.asl")}

/* Demand and Satisfaction could be low, medium, or high. 
 * Satisfaction could also be evaluation.
 * Hard-coded beliefs. */
type("University").
demand(low).
event(none).

/* Historical allocations. */
allocations::totalAllocations(25, 1, 2026).
allocations::totalAllocations(20, 2, 2026).
allocations::totalAllocations(35, 3, 2026).
allocations::totalAllocations(40, 4, 2026).

/* Historical restrictions. */
restrictions::totalRestrictions(10, 1, 2026).
restrictions::totalRestrictions(15, 2, 2026).
restrictions::totalRestrictions(11, 3, 2026).
restrictions::totalRestrictions(18, 4, 2026).

!reportStatus.

+ticket(Id) <-
	.print("I received the ticket ", Id, ".");
	.send(auditor, achieve, accountability(Id));
	.send(auditor, achieve, responsibility(Id)).