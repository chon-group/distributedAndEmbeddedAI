/* It sends a register to the auditor concerning the explainability and responsibility of an act. */
+!auditAndReply(Id, Client, Message) <-
	.time(H, Min, S);
	.date(Y, M, D);
	.concat(Id, Y, M, D, S, Min, H, "-", Client, Ticket); 
	.my_name(Responsible);
	.send(auditor, tell, operation(Ticket,
				    Client, 
				    Responsible, 
				    Message, 
				    accountability));
	.send(Client, tell, ticket(Ticket)).