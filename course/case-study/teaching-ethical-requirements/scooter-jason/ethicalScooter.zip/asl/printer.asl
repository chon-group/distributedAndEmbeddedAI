+!printZoneStatus(Sender, Z, T, D, A, I, E) <-
    	.print(
        	"Received from: ", Sender,
        	"\n  - Zone: ", Z,
        	"\n  - Type: ", T,
        	"\n  - Demand: ", D,
        	"\n  - Available: ", A,
        	"\n  - Inactive: ", I,
        	"\n  - Event: ", E,
        	"\n"
    	).

+!printZoneTransfer(SourceZone, TargetZone, Qty) <-
    	.print("[ZONE TRANSFER] Transferindo ", Qty, " patinetes de ", SourceZone, " para ", TargetZone, ".").
