{include("manager.asl")}
{include("reporting.asl")}
{include("tracer.asl")}
{include("fleet.asl")}
{include("marketing.asl")}

/* Demand and Satisfaction could be low, medium, or high. 
 * Satisfaction could also be evaluation.
 * Hard-coded beliefs. */
demand(low).
type("Neighborhood").
event(none).

/* Historical allocations. */
allocations::totalAllocations(11, 1, 2026).
allocations::totalAllocations(12, 2, 2026).
allocations::totalAllocations(14, 3, 2026).
allocations::totalAllocations(16, 4, 2026).

/* Historical restrictions. */
restrictions::totalRestrictions(10, 1, 2026).
restrictions::totalRestrictions(10, 2, 2026).
restrictions::totalRestrictions(11, 3, 2026).
restrictions::totalRestrictions(15, 4, 2026).

!reportStatus.

+ticket(Id) <-
	.print("I received the ticket ", Id, ".");
	.send(auditor, achieve, accountability(Id));
	.send(auditor, achieve, responsibility(Id)).