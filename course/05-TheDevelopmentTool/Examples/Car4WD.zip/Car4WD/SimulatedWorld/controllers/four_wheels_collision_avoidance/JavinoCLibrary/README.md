# JavinoCLibrary
A library to implement the Javino protocol written in C
